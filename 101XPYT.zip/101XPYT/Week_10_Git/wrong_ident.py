def function():
    for i in range(5):
	print(i)

function()