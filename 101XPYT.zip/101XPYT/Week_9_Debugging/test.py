import pdb

def divide(a, b):
    result = a / b
    return result

pdb.set_trace()
x = 10
y = 0
result = divide(x, y)
print("Result: ", result)